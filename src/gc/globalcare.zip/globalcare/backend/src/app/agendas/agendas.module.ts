import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

import { AgendasComponent } from './agendas.component';
import { AgendaDetalheComponent } from './agenda-detalhe/agenda-detalhe.component';
import { AgendaNaoEncontradaComponent } from './agenda-nao-encontrada/agenda-nao-encontrada.component';
import { AgendasService } from './agendas.service';
import { AgendasRoutingModule } from './agendas.routing.module';

@NgModule({
    imports: [
        CommonModule,
        AgendasRoutingModule
    ],
    exports: [],
    declarations: [
        AgendasComponent,
        AgendaDetalheComponent,
        AgendaNaoEncontradaComponent
    ],
    providers: [ AgendasService ]
})
export class AgendasModule {

}