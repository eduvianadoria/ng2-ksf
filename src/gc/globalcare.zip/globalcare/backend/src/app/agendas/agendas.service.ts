import { Injectable } from '@angular/core';

import { BackendService, ResponseAll} from 'ng2-ksf';
import {Observable} from 'rxjs';

@Injectable()
export class AgendasService {

    listar(): PromiseLike<ResponseAll> {

        return new Promise((resolve, reject) => {       
            this.backendService
                .getAll('http://localhost:3000/v1/agendas')
                .subscribe(
                    result => {
                        resolve(result);
                    },
                    erro => reject(erro)
                );
        });

    }

    getAgendas() {
      return [
        {id: 1, nome: 'Agenda 1'},
        {id: 2, nome: 'Agenda 2'}
      ];
    }

  getAgenda(id: number) {
    return null;
  }

  constructor(
    private backendService: BackendService
  ) { }

}
