import { NgModule } from '@angular/core';

import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AgendasComponent } from './agendas.component';
import { AgendaDetalheComponent } from './agenda-detalhe/agenda-detalhe.component';
import { AgendaNaoEncontradaComponent } from './agenda-nao-encontrada/agenda-nao-encontrada.component';

const agendasRoutes: Routes = [
    { path: 'agendas', component: AgendasComponent},
    { path: 'agenda/:id', component: AgendaDetalheComponent},
    { path: 'naoEncontrado', component: AgendaNaoEncontradaComponent}
];

@NgModule({
    imports: [ RouterModule.forChild(agendasRoutes) ],
    exports: [ RouterModule ]
})
export class AgendasRoutingModule {}