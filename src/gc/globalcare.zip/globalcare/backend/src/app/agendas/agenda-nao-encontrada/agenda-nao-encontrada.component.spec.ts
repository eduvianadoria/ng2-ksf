import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgendaNaoEncontradaComponent } from './agenda-nao-encontrada.component';

describe('AgendaNaoEncontradaComponent', () => {
  let component: AgendaNaoEncontradaComponent;
  let fixture: ComponentFixture<AgendaNaoEncontradaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgendaNaoEncontradaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgendaNaoEncontradaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
