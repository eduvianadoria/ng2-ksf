import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agenda-nao-encontrada',
  templateUrl: './agenda-nao-encontrada.component.html',
  styleUrls: ['./agenda-nao-encontrada.component.css']
})
export class AgendaNaoEncontradaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
