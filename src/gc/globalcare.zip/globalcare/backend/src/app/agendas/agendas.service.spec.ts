import { TestBed, inject } from '@angular/core/testing';

import { AgendasService } from './agendas.service';

describe('AgendasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgendasService]
    });
  });

  it('should be created', inject([AgendasService], (service: AgendasService) => {
    expect(service).toBeTruthy();
  }));
});
