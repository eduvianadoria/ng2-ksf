import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';

import { AgendasService } from '../agendas.service';

@Component({
  selector: 'app-agenda-detalhe',
  templateUrl: './agenda-detalhe.component.html',
  styleUrls: ['./agenda-detalhe.component.css']
})
export class AgendaDetalheComponent implements OnInit, OnDestroy {

  id: number;
  inscricao: Subscription;
  agenda: any;

  constructor(
    private route: ActivatedRoute, 
    private router: Router,
    private agendasService: AgendasService
  ) { }

  ngOnInit() {
    this.inscricao = this.route.params.subscribe(
      (params: any) => {
        this.id = params['id'];

        this.agenda = this.agendasService.getAgenda(this.id);

        if (this.agenda == null) {
          this.router.navigate(['naoEncontrado']);
        }
    });
  }

  ngOnDestroy() {
    this.inscricao.unsubscribe();
  }
}
