import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Rx';

import { AgendasService } from './agendas.service';
import { ResponseAll } from 'ng2-ksf';

@Component({
  selector: 'app-agendas',
  templateUrl: './agendas.component.html',
  styleUrls: ['./agendas.component.css']
})
export class AgendasComponent implements OnInit, OnDestroy {

  agendas: any[];
  pagina: number;
  inscricao: Subscription;

  constructor(
    private agendasService: AgendasService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {

    this.agendasService
        .listar()
        .then( (response: ResponseAll) => {
          console.log(response);
        });

    this.agendas = this.agendasService.getAgendas();
    this.inscricao = this.route.queryParams.subscribe(
      (queryParams: any) => {
        this.pagina = queryParams['pagina'];
      }
    )
  }

  ngOnDestroy() {
    this.inscricao.unsubscribe();
  }

}
