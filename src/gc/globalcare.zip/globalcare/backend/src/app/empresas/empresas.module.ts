import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmpresasComponent } from './empresas.component';
import { EmpresaFormComponent } from './empresa-form/empresa-form.component';
import { EmpresaDetalheComponent } from './empresa-detalhe/empresa-detalhe.component';
import { EmpresasRoutingModule } from './empresas.routing.module';

@NgModule({
    imports: [
        CommonModule,
        EmpresasRoutingModule
    ],
    exports: [],
    declarations: [
        EmpresasComponent, 
        EmpresaFormComponent, 
        EmpresaDetalheComponent
    ],
    providers: [],
})
export class EmpresasModule { }
