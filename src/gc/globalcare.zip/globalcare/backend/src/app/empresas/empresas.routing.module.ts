import { NgModule, Component } from '@angular/core';
import { RouterModule } from '@angular/router';

import { EmpresasComponent } from './empresas.component';
import { EmpresaDetalheComponent } from './empresa-detalhe/empresa-detalhe.component';
import { EmpresaFormComponent } from './empresa-form/empresa-form.component';


// Rotas padrão...
// const empresasRoutes = [
//     {path: 'empresas', component: EmpresasComponent},
//     {path: 'empresa/novo', component: EmpresaFormComponent},
//     {path: 'empresa/:id', component: EmpresaDetalheComponent},
//     {path: 'empresa/:id/editar', component: EmpresaFormComponent}
// ];

// Rotas filha...
const empresasRoutes = [
    {path: 'empresas', component: EmpresasComponent, children: [
        {path: 'novo', component: EmpresaFormComponent},
        {path: ':id', component: EmpresaDetalheComponent},
        {path: ':id/editar', component: EmpresaFormComponent}
    ]}
    
];

@NgModule({
    imports: [ RouterModule.forChild(empresasRoutes)],
    exports: [ RouterModule ]
})
export class EmpresasRoutingModule {}