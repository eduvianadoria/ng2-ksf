import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-detalhe',
  templateUrl: './empresa-detalhe.component.html',
  styleUrls: ['./empresa-detalhe.component.css']
})
export class EmpresaDetalheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
