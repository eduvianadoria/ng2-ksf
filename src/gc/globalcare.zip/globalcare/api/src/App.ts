import * as path from 'path';
import * as express from 'express';
import * as logger from 'morgan';
import * as bodyParser from 'body-parser';

import {Config} from './config';

import {UsuarioController} from "./controllers/UsuarioController";
import {StatusController} from "./controllers/StatusController";
import {AgendaController} from "./controllers/AgendaController";
import {SetorController} from "./controllers/SetorController";
import {EmpresaController} from "./controllers/EmpresaController";
import {PerfilController} from "./controllers/PerfilController";

import {Promise} from 'sequelize';
import {Sequelize} from 'sequelize-typescript';

class App {

  // ref to Express instance
  public express: express.Application;
  _config: Config;

  //Run configuration methods on the Express instance.
  constructor() {
    this._config = new Config();
    this.express = express();
    this.middleware();
    this.routes();
  }

  // Configure Express middleware.
  private middleware(): void {
    this.express.use(logger('dev'));
    this.express.use(bodyParser.json());
    this.express.use(bodyParser.urlencoded({ extended: false }));
  }

  // Configure API endpoints.
  private routes(): void {

    const sequelize = new Sequelize({
      name: this._config.database,
      dialect: this._config.dialect,
      host: this._config.host,
      username: this._config.username,
      password: this._config.password,
      modelPaths: [
        __dirname + '/models'
      ]
    });

    sequelize
      .sync({force: false})
      .then(() => {
          this.express.use(express.static(this._config.baseBackEnd));

          // Rotas: Perfil
          let perfilController = new PerfilController();
          this.express.get("/v1/perfis", perfilController.getAll);
          this.express.get("/v1/perfil/:id(\\d+)", perfilController.getOne);
          this.express.post("/v1/perfil", perfilController.add);
          this.express.put("/v1/perfil/:id(\\d+)", perfilController.update);
          this.express.delete("/v1/perfil/:id(\\d+)", perfilController.delete);

          //Rotas: Empresa
          let empresaController = new EmpresaController();
          this.express.get("/v1/empresas", empresaController.getAll);
          this.express.get("/v1/empresa/:id(\\d+)", empresaController.getOne);
          this.express.post("/v1/empresa", empresaController.add);
          this.express.put("/v1/empresa/:id(\\d+)", empresaController.update);
          this.express.delete("/v1/empresa/:id(\\d+)", empresaController.delete);   

          // Rotas: Setor
          let setorController = new SetorController();
          this.express.get("/v1/setores", setorController.getAll);
          this.express.get("/v1/setor/:id(\\d+)", setorController.getOne);
          this.express.post("/v1/setor", setorController.add);
          this.express.put("/v1/setor/:id(\\d+)", setorController.update);
          this.express.delete("/v1/setor/:id(\\d+)", setorController.delete);

          // Rotas: Status
          let statusController = new StatusController();
          this.express.get("/v1/status", statusController.getAll);
          this.express.get("/v1/status/:id(\\d+)", statusController.getOne);
          this.express.post("/v1/status", statusController.add);
          this.express.put("/v1/status/:id(\\d+)", statusController.update);
          this.express.delete("/v1/status/:id(\\d+)", statusController.delete);

          // Rotas: Agenda
          let agendaController = new AgendaController();
          this.express.get("/v1/agendas", agendaController.getAll);
          this.express.get("/v1/agenda/:id(\\d+)", agendaController.getOne);
          this.express.get("/v1/agenda", agendaController.filter);
          this.express.post("/v1/agenda", agendaController.add);
          this.express.put("/v1/agenda/:id(\\d+)", agendaController.update);
          this.express.delete("/v1/agenda/:id(\\d+)", agendaController.delete);

          // Rotas: Usuário
          let usuarioController = new UsuarioController();
          this.express.post("/v1/usuario/autenticar", usuarioController.autenticar);
          this.express.post("/v1/usuario/validar-token", usuarioController.validarToken);
          this.express.get("/v1/usuarios", usuarioController.getAll);
          this.express.get("/v1/usuario/:id(\\d+)", usuarioController.getOne);
          this.express.post("/v1/usuario", usuarioController.post);
          this.express.put("/v1/usuario/:id(\\d+)", usuarioController.put);
          this.express.delete("/v1/usuario/:id(\\d+)", usuarioController.delete);

          // backend ...
          let routerBackEnd = express.Router();
          routerBackEnd.all('/*', (req, res, next) => {
              res.sendFile(this._config.baseBackEnd + 'index.html');
          });
          this.express.use('/*', routerBackEnd);      
      });
  }
}

export default new App().express;