import * as Promise from "bluebird";
import { Perfil } from '../models/Perfil';
import { PerfilEntity } from '../entity/PerfilEntity';

export class PerfilService {

    constructor() {}

    list(): Promise<any> {
        return Perfil.findAll<Perfil>();
    }

    findById(id: number): Promise<any> {
        return Perfil.findOne<Perfil>({where: {id: id}});
    }

    save(perfilEntity: PerfilEntity): Promise<any> {
        if (perfilEntity.id == null) {
            return Perfil.create<Perfil>(perfilEntity);
        } else {
            return Perfil.update<Perfil>(perfilEntity, {where: {id: perfilEntity.id}});
        }
    }

    destroy(id: number): Promise<any> {
        return Perfil.destroy({ where: {id: id} });
    }
}