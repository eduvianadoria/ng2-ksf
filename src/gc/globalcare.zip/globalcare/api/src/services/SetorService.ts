import * as Promise from "bluebird";
import { Setor } from '../models/Setor';
import { SetorEntity } from '../entity/SetorEntity';

export class SetorService {

    constructor() {}

    list(): Promise<any> {
        return Setor.findAll<Setor>();
    }

    findById(id: number): Promise<any> {
        return Setor.findOne<Setor>({where: {id: id}});
    }

    save(setorEntity: SetorEntity): Promise<any> {
        if (setorEntity.id == null) {
            return Setor.create<Setor>(setorEntity);
        } else {
            return Setor.update<Setor>(setorEntity, {where: {id: setorEntity.id}});
        }
    }

    destroy(id: number): Promise<any> {
        return Setor.destroy({ where: {id: id} });
    }
}