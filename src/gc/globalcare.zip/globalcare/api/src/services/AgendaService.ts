import * as Promise from "bluebird";
import { Agenda } from '../models/Agenda';
import { AgendaEntity } from '../entity/AgendaEntity';

export class AgendaService {

    constructor() {}

    list(): Promise<any> {
        return Agenda.findAll<Agenda>();
    }

    findById(id: number): Promise<any> {
        return Agenda.findOne<Agenda>({where: {id: id}});
    }

    findByDate(date: Date): Promise<any> {
        return Agenda.findAll<Agenda>({
                where: {data: date},
                order: 'hora asc'
            });
    }

    save(agendaEntity: AgendaEntity): Promise<any> {
        if (agendaEntity.id == null) {
            return Agenda.create<Agenda>(agendaEntity);
        } else {
            return Agenda.update<Agenda>(agendaEntity, {where: {id: agendaEntity.id}});
        }
    }

    destroy(id: number): Promise<any> {
        return Agenda.destroy({ where: {id: id} });
    }
}