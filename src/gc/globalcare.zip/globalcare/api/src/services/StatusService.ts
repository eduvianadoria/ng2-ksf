import * as Promise from "bluebird";
import { Status } from '../models/Status';
import { StatusEntity } from '../entity/StatusEntity';

export class StatusService {

    constructor() {}

    list(): Promise<any> {
        return Status.findAll<Status>();
    }

    findById(id: number): Promise<any> {
        return Status.findOne<Status>({where: {id: id}});
    }

    save(statusEntity: StatusEntity): Promise<any> {
        if (statusEntity.id == null) {
            return Status.create<Status>(statusEntity);
        } else {
            return Status.update<Status>(statusEntity, {where: {id: statusEntity.id}});
        }
    }

    destroy(id: number): Promise<any> {
        return Status.destroy({ where: {id: id} });
    }
}