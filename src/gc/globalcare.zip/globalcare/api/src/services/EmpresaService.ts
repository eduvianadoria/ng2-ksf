import * as Promise from "bluebird";
import { Empresa } from '../models/Empresa';
import { EmpresaEntity } from '../entity/EmpresaEntity';

export class EmpresaService {

    list(): Promise<any> {
        return Empresa.findAll<Empresa>();
    }

    findById(id: number): Promise<any> {
        return Empresa.findOne<Empresa>({where: {id: id}});
    }

    save(empresa: EmpresaEntity): Promise<any> {
        if (empresa.id == null) {
            return Empresa.create<Empresa>(empresa);
        } else {
            return Empresa.update<Empresa>(empresa, {where: {id: empresa.id}});
        }
    }

    destroy(id: number): Promise<any> {
        return Empresa.destroy({ where: {id: id} });
    }
}