export class SetorEntity {

    id: number;
    idEmpresa: number;
    nome: string;
}