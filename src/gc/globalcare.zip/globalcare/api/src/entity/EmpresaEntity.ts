export class EmpresaEntity {

    id: number;
    nome: string;
    cnpj: string;
    razaoSocial: string;
}