export class Usuario {
}