export class StatusEntity {

    id: number;
    codigo: string;
    ativo: number;
    nome: string;
    descricao: string;
}