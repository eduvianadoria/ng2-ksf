export class AgendaEntity {

    id: number;
    data: Date;
    hora: string;
    idStatus: number;
    idSetor: number;
    idUsuario: number;
    titulo: string;
    observacao: string;
}