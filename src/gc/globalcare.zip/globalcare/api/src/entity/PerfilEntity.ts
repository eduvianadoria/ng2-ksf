export class PerfilEntity {

    id: number;
    codigo: string;
    ativo: number;
    nome: string;
    descricao: string;

}