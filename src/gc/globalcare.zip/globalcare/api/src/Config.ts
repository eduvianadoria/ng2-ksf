export class Config {
    private _database : string = "globalcare";
    private _dialect : string = "mysql";
    private _host : string = "localhost";
    private _username : string = "root";
    private _password : string = "liDUfab0";
    private _params : Object = {
        dialect: "mysql",
        logging: (sql) => {
          //logger.info(`[${new Date()}] ${sql}`);
        },
        define: {
          underscored: true
        }
    };
    private _jwtSecret : string = "AP1";
    private _jwtSession : Object = {
      session: false
    };
    private _baseBackEnd : string = "C:/GlobalWeb/Projetos/globalcare/backend/";

    get database () {
        return this._database;
    }
    get dialect () {
        return this._dialect;
    }
    get host () {
        return this._host;
    }
    get username () {
        return this._username;
    }
    get password() {
        return this._password;
    }
    get params () {
        return this._params;
    }
    get jwtSecret () {
        return this._jwtSecret;
    }
    get jwtSession () {
        return this._jwtSession;
    }
    get baseBackEnd () {
        return this._baseBackEnd;
    }
}