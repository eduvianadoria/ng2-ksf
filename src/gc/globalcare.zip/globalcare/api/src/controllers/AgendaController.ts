import * as express from "express";
import { AgendaService } from '../services/AgendaService';
import { AgendaEntity } from '../entity/AgendaEntity';

export class AgendaController {

    private _agendaService: AgendaService;

    constructor() {
        this._agendaService = new AgendaService();
    }

    getAll = (req:express.Request, res:express.Response) => {
        this._agendaService
            .list()
            .then(list => {
                res.status(201).send(list);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    getOne = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._agendaService
            .findById(id)
            .then(result => {
                if (result != null) {
                    res.status(200).send(result);
                } else {
                    res.sendStatus(404);
                }
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    filter = (req:express.Request, res:express.Response) => {
        let dataQuery = req.query.data;
        if (dataQuery != null) {
            let date = new Date(dataQuery);
            this._agendaService
                .findByDate(date)
                .then(list => {
                    if (list != null) {
                        res.status(200).send(list);
                    } else {
                        res.sendStatus(404);
                    }
                })
                .catch((err:any) => {
                    res.send(err);
                });
        } else {
            res.sendStatus(500);
        }
    };

    add = (req:express.Request, res:express.Response) => {
        let data = req.body.data;
        let hora = req.body.hora;
        let idStatus = req.body.idStatus;
        let idSetor = req.body.idSetor;
        let idUsuario = req.body.idUsuario;
        let titulo = req.body.titulo;
        let observacao = req.body.observacao;

        //TODO: efetuar as validações necessárias

        let agendaEntity = new AgendaEntity();
        agendaEntity.data = new Date(data);
        agendaEntity.hora = hora;
        agendaEntity.idStatus = idStatus;
        agendaEntity.idSetor = idSetor;
        agendaEntity.idUsuario = idUsuario;
        agendaEntity.titulo = titulo;
        agendaEntity.observacao = observacao;

        this._agendaService
            .save(agendaEntity)
            .then(result => {
                res.status(201).send(result);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    update = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;

        let data = req.body.data;
        let hora = req.body.hora;
        let idStatus = req.body.idStatus;
        let idSetor = req.body.idSetor;
        let idUsuario = req.body.idUsuario;
        let titulo = req.body.titulo;
        let observacao = req.body.observacao;

        //TODO: efetuar as validações necessárias

        let agendaEntity = new AgendaEntity();
        agendaEntity.id = id;
        agendaEntity.data = new Date(data);
        agendaEntity.hora = hora;
        agendaEntity.idStatus = idStatus;
        agendaEntity.idSetor = idSetor;
        agendaEntity.idUsuario = idUsuario;
        agendaEntity.titulo = titulo;
        agendaEntity.observacao = observacao;

        this._agendaService
            .save(agendaEntity)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    delete = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._agendaService
            .destroy(id)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };
}