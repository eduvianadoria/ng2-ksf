import * as express from "express";
import { StatusService } from '../services/StatusService';
import { StatusEntity } from '../entity/StatusEntity';

export class StatusController {

    private _statusService: StatusService;

    constructor() {
        this._statusService = new StatusService();
    }

    getAll = (req:express.Request, res:express.Response) => {
        this._statusService
            .list()
            .then(list => {
                res.status(201).send(list);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    getOne = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._statusService
            .findById(id)
            .then(result => {
                if (result != null) {
                    res.status(200).send(result);
                } else {
                    res.sendStatus(404);
                }
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    add = (req:express.Request, res:express.Response) => {
        let codigo = req.body.codigo;
        let ativo = req.body.ativo;
        let nome = req.body.nome;
        let descricao = req.body.descricao;

        //TODO: efetuar as validações necessárias

        let statusEntity = new StatusEntity();
        statusEntity.codigo = codigo;
        statusEntity.ativo = ativo;
        statusEntity.nome = nome;
        statusEntity.descricao = descricao;

        this._statusService
            .save(statusEntity)
            .then(result => {
                res.status(201).send(result);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    update = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;

        let codigo = req.body.codigo;
        let ativo = req.body.ativo;
        let nome = req.body.nome;
        let descricao = req.body.descricao;

        //TODO: efetuar as validações necessárias

        let statusEntity = new StatusEntity();
        statusEntity.id = id;
        statusEntity.codigo = codigo;
        statusEntity.ativo = ativo;
        statusEntity.nome = nome;
        statusEntity.descricao = descricao;

        this._statusService
            .save(statusEntity)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    delete = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._statusService
            .destroy(id)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };
}