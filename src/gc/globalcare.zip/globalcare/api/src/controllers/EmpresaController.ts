import * as express from "express";
import { EmpresaService } from '../services/EmpresaService';
import { EmpresaEntity } from '../entity/EmpresaEntity';

export class EmpresaController {

    private _empresaService: EmpresaService;

    constructor() {
        this._empresaService = new EmpresaService();
    }

    getAll = (req:express.Request, res:express.Response) => {
        this._empresaService
            .list()
            .then(list => {
                res.status(201).send(list);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    getOne = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._empresaService
            .findById(id)
            .then(result => {
                if (result != null) {
                    res.status(200).send(result);
                } else {
                    res.sendStatus(404);
                }
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    add = (req:express.Request, res:express.Response) => {
        let nome = req.body.nome;
        let cnpj = req.body.cnpj;
        let razaoSocial = req.body.razaoSocial;

        //TODO: efetuar as validações necessárias

        let empresa = new EmpresaEntity();
        empresa.nome = nome;
        empresa.cnpj = cnpj;
        empresa.razaoSocial = razaoSocial;

        this._empresaService
            .save(empresa)
            .then(result => {
                res.status(201).send(result);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    update = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;

        let nome = req.body.nome;
        let cnpj = req.body.cnpj;
        let razaoSocial = req.body.razaoSocial;

        //TODO: efetuar as validações necessárias

        let empresa = new EmpresaEntity();
        empresa.id = id;
        empresa.nome = nome;
        empresa.cnpj = cnpj;
        empresa.razaoSocial = razaoSocial;

        this._empresaService
            .save(empresa)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    delete = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._empresaService
            .destroy(id)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };
}