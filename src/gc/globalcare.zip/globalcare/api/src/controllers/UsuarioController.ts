import * as express from "express";

export class UsuarioController {

    autenticar = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    validarToken = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    getAll = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    getOne = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    post = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    put = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

    delete = (req:express.Request, res:express.Response) => {
        res.sendStatus(200);
    };

}