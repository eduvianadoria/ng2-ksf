import * as express from "express";
import { SetorService } from '../services/SetorService';
import { SetorEntity } from '../entity/SetorEntity';

export class SetorController {

    private _setorService: SetorService;

    constructor() {
        this._setorService = new SetorService();
    }

    getAll = (req:express.Request, res:express.Response) => {
        this._setorService
            .list()
            .then(list => {
                res.status(201).send(list);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    getOne = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._setorService
            .findById(id)
            .then(result => {
                if (result != null) {
                    res.status(200).send(result);
                } else {
                    res.sendStatus(404);
                }
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    add = (req:express.Request, res:express.Response) => {
        let idEmpresa = req.body.idEmpresa;
        let nome = req.body.nome;

        //TODO: efetuar as validações necessárias

        let setor = new SetorEntity();
        setor.idEmpresa = idEmpresa;
        setor.nome = nome;

        this._setorService
            .save(setor)
            .then(result => {
                res.status(201).send(result);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    update = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;

        let idEmpresa = req.body.idEmpresa;
        let nome = req.body.nome;

        //TODO: efetuar as validações necessárias

        let setor = new SetorEntity();
        setor.id = id;
        setor.idEmpresa = idEmpresa;
        setor.nome = nome;

        this._setorService
            .save(setor)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };

    delete = (req:express.Request, res:express.Response) => {
        let id: number = req.params.id;
        this._setorService
            .destroy(id)
            .then(result => {
                res.sendStatus(200);
            })
            .catch((err:any) => {
                res.status(500).send({error: err.message});
            });
    };
}