import {Table, Model, PrimaryKey, DataType, Column, AllowNull, AutoIncrement, BelongsToMany, DefaultScope, Scopes} from 'sequelize-typescript';

@DefaultScope({
  attributes: ['id', 'data', 'hora', 'idStatus', 'idSetor', 'idUsuario', 'titulo', 'observacao']
})
@Table({
  timestamps: false,
  tableName: "agenda"
})
export class Agenda extends Model<Agenda> {

    @PrimaryKey
    @AutoIncrement
    @Column(DataType.INTEGER)
    id: number;

    @Column(DataType.DATE)
    data: Date;

    @Column(DataType.TEXT)
    hora: string;

    @Column(DataType.INTEGER)
    idStatus: number;

    @Column(DataType.INTEGER)
    idSetor: number;

    @Column(DataType.INTEGER)
    idUsuario: number;

    @Column(DataType.TEXT)
    titulo: string;

    @Column(DataType.TEXT)
    observacao: string;
}