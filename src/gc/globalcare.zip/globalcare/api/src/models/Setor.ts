import {Table, Model, PrimaryKey, DataType, Column, AutoIncrement, DefaultScope} from 'sequelize-typescript';

@DefaultScope({
  attributes: ['id', 'idEmpresa', 'nome']
})
@Table({
  timestamps: false,
  tableName: "setor"
})
export class Setor extends Model<Setor> {

    @PrimaryKey
    @AutoIncrement
    @Column(DataType.INTEGER)
    id: number;

    @Column(DataType.INTEGER)
    idEmpresa: number;

    @Column(DataType.TEXT)
    nome: string;
}