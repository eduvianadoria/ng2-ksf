import {Table, Model, PrimaryKey, DataType, Column, AllowNull, AutoIncrement, BelongsToMany, DefaultScope, Scopes} from 'sequelize-typescript';

@DefaultScope({
  attributes: ['id', 'codigo', 'ativo', 'nome', 'descricao']
})
@Table({
  timestamps: false,
  tableName: "perfil"
})
export class Perfil extends Model<Perfil> {

  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  id: number;

  @Column(DataType.TEXT)
  codigo: string;

  @Column(DataType.INTEGER)
  ativo: number;

  @Column(DataType.TEXT)
  nome: string;

  @AllowNull
  @Column(DataType.TEXT)
  descricao: string;
}