import {Table, Model, PrimaryKey, DataType, Column, AutoIncrement, DefaultScope} from 'sequelize-typescript';

@DefaultScope({
  attributes: ['id', 'nome', 'cnpj', 'razaoSocial']
})
@Table({
  timestamps: false,
  tableName: "empresa"
})
export class Empresa extends Model<Empresa> {

    @PrimaryKey
    @AutoIncrement
    @Column(DataType.INTEGER)
    id: number;

    @Column(DataType.TEXT)
    nome: string;

    @Column(DataType.TEXT)
    cnpj: string;

    @Column(DataType.TEXT)
    razaoSocial: string;
}