import {Table, Model, PrimaryKey, DataType, Column, AutoIncrement, DefaultScope} from 'sequelize-typescript';

@DefaultScope({
  attributes: ['id', 'codigo', 'ativo', 'nome', 'descricao']
})
@Table({
  timestamps: false,
  tableName: "status"
})
export class Status extends Model<Status> {

    @PrimaryKey
    @AutoIncrement
    @Column(DataType.INTEGER)
    id: number;

    @Column(DataType.TEXT)
    codigo: string;

    @Column(DataType.INTEGER)
    ativo: number;

    @Column(DataType.TEXT)
    nome: string;

    @Column(DataType.TEXT)
    descricao: string;
}